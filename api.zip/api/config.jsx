export const apiUrl = 'http://192.168.1.11:8000/api/';
export const apiImage = 'http://192.168.1.11:8000';
